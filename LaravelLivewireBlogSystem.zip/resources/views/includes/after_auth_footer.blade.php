<footer class="text-center text-gray-500 text-sm py-6">
    &copy; {{ date('Y') }} MyBlog. All rights reserved.
</footer>
