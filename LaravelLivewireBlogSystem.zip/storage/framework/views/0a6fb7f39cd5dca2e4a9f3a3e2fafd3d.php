<?php $__env->startSection('content'); ?>
    <!-- Top Header -->
    <?php echo $__env->make('includes.after_auth_header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


    <main class="flex-1 mt-5 px-2 max-w-4xl mx-auto">
        <?php echo $__env->make('includes.flashMessages', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php if(Auth::user()->role === 'admin'): ?>
            <div class="max-w-6xl mx-auto p-6">
                <h2 class="text-2xl font-bold mb-6">Admin Dashboard</h2>
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('admin-dashboard-stats', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-616245519-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </div>
        <?php endif; ?>

        <?php if(Auth::user()->role === 'user'): ?>
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-3xl font-bold text-gray-800">Blog Posts</h1>
                <a href="<?php echo e(route('getPostCreate')); ?>"
                    class="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-lg shadow transition">
                    + Create Post
                </a>
            </div>
        <?php endif; ?>

        <!-- Dynamic Posts -->
        <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <!-- Post 1 -->
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('pages.blog.single_blog_post', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="mt-5">
            <?php echo e($posts->links()); ?>

        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\LaravelLivewireBlogSystem\resources\views/pages/blog/dashboard.blade.php ENDPATH**/ ?>