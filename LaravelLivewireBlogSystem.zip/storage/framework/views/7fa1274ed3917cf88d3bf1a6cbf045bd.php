<div wire:poll.20s="loadComments">
    <div class="space-y-5">
        <?php echo $__env->make('includes.flashMessages', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="bg-gray-50 border border-gray-200 rounded-xl p-4 shadow-sm relative group">
                <div class="flex items-start justify-between mb-1">
                    <div>
                        <div class="font-semibold text-gray-800">
                            <?php echo e($comment->user->name ?? 'Anonymous'); ?>

                        </div>
                        <div class="text-sm text-gray-500">
                            <?php echo e($comment->created_at->diffForHumans()); ?>

                        </div>
                    </div>


                    <!--[if BLOCK]><![endif]--><?php if(auth()->id() === $comment->user_id): ?>
                        <div class="flex space-x-2 opacity-0 group-hover:opacity-100 transition">


                            <button wire:click="deleteComment(<?php echo e($comment->id); ?>)"
                                class="text-red-600 hover:text-red-800" title="Delete Comment"
                                wire:confirm="Are you sure you want to delete this comment?">
                                <i class="fa fa-trash"></i>
                            </button>
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <p class="text-gray-700 leading-relaxed mt-2"><?php echo e($comment->content); ?></p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="text-gray-500 italic">
                <center>No comments yet. Be the first to share your thoughts!</center>
            </p>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>
</div>
<?php /**PATH D:\laragon\www\LaravelLivewireBlogSystem\resources\views/livewire/comment-list.blade.php ENDPATH**/ ?>