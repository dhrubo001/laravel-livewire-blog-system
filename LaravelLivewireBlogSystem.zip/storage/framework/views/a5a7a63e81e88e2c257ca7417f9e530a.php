<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('includes.after_auth_header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('update-post', ['postId' => $postId]);

$__html = app('livewire')->mount($__name, $__params, 'lw-918879247-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\LaravelLivewireBlogSystem\resources\views/pages/blog/update_blog.blade.php ENDPATH**/ ?>