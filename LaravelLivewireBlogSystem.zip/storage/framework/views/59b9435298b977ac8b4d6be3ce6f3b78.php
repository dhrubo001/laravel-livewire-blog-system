<div>
    <?php echo $__env->make('includes.flashMessages', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <form wire:submit.prevent="postComment" class="mb-8 space-y-4">
        <textarea wire:model.defer="commentText"
            class="w-full border border-gray-300 rounded-lg px-4 py-3 h-24 focus:border-blue-500 focus:ring focus:ring-blue-100 outline-none resize-none"
            placeholder="Write a comment..."></textarea>
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['commentText'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-red-500 text-sm"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

        <div class="flex justify-end">
            <button type="submit"
                class="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-5 py-2 rounded-lg shadow transition">
                Post Comment
            </button>
        </div>
    </form>
</div>
<?php /**PATH D:\laragon\www\LaravelLivewireBlogSystem\resources\views/livewire/post-comment.blade.php ENDPATH**/ ?>