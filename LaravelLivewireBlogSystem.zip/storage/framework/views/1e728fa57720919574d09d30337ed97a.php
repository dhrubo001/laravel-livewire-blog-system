<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('includes.after_auth_header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- 📝 Blog Content -->
    <main class="flex-1 mt-24 px-6 max-w-4xl mx-auto">
        <div class="bg-white rounded-2xl shadow-lg overflow-hidden">

            <!-- Blog Details -->
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('post', ['post' => $post]);

$__html = app('livewire')->mount($__name, $__params, 'lw-3797948924-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </div>

        <div class="mt-10">
            <h2 class="text-2xl font-bold text-gray-800 mb-6">Comments</h2>

            <!-- Add Comment Form -->
            <?php if(auth()->guard()->check()): ?>
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('post-comment', ['postId' => $post->id]);

$__html = app('livewire')->mount($__name, $__params, 'lw-3797948924-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <?php else: ?>
                <p class="text-gray-600">Please <a href="<?php echo e(route('getLogin')); ?>" class="text-blue-600 font-medium">login</a> to
                    add a comment.</p>
            <?php endif; ?>

            <!-- Comments List -->
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('comment-list', ['postId' => $post->id]);

$__html = app('livewire')->mount($__name, $__params, 'lw-3797948924-2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </div>

    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\LaravelLivewireBlogSystem\resources\views/pages/blog/detail_blog.blade.php ENDPATH**/ ?>